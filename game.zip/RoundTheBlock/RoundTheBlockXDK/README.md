Round the Block
Converting Round the Block to Enchant.js game

###########################
# Blank Game Template

See [LICENSE.md]() for license terms and conditions.

Use this template as a starting point for creating an Intel XDK game app.

This Intel XDK project just have required files including index.html, asset folder, and basic CSS and Javascript file.

Intel(R) XDK
-------------------------------------------
This template is part of the Intel(R) XDK. Please sign up or download the Intel XDK at http://software.intel.com/en-us/html5.

Application Files:
-----------------
* LICENSE.md
* README.md
* index.html
* asset/logo.png
* css/app.css
* js/app.js
* js/corodva-init.js